import os

for i in range(140,150):
	os.mknod(str(i)+".bpl")